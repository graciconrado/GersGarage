<?php

use yii\db\Migration;

class m200803_190305_create_table_appointments extends Migration
{
    public function safeUp()
    {
        $this->createTable('appointments', [
            'id' => $this->primaryKey(),
            'date' => $this->date()->notNull(),
            'status' => $this->smallInteger(1)->notNull()->defaultValue(1),
            'comment' => $this->string(60),
            'id_customer' => $this->integer(11)->notNull(),
            'id_car' => $this->integer(11)->notNull(),
            'id_mechanic' => $this->integer(11),
        ]);

        $this->addForeignKey('fk_id_customer', 'appointments', 'id_customer', 'users', 'userId');
        $this->addForeignKey('fk_id_car', 'appointments', 'id_car', 'cars', 'id');
        $this->addForeignKey('fk_id_mechanic', 'appointments', 'id_mechanic', 'users', 'userId');
    }

    public function safeDown()
    {
        $this->dropTable('appointments');
    }
}
