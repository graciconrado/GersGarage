<?php

use yii\db\Migration;

/**
 * Class m200811_185345_create_table_app_status
 */
class m200811_185345_create_table_app_status extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('appStatus',[
            'id' => $this->primaryKey(),
            'status' => $this->string(40)->notNull(),
        ]);

        $this->insert('appStatus',['status' => 'Booked']);
        $this->insert('appStatus',['status' => 'In service']);
        $this->insert('appStatus',['status' => 'Fixed']);
        $this->insert('appStatus',['status' => 'Collected']);
        $this->insert('appStatus',['status' => 'Unrepairable']);
        $this->insert('appStatus',['status' => 'Cancelled']);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        $this->dropTable('appStatus');
    }
}
