<?php

use yii\db\Migration;

class m200813_165750_create_table_invoiceProduct extends Migration
{
    public function safeUp()
    {
        $this->createTable('invoiceProduct', [
            'id' => $this->primaryKey(),
            'id_invoice' => $this->integer(11)->notNull(),
            'id_product' => $this->integer(11)->notNull(),
            'quantItem' => $this->smallInteger(3)->notNull(),
        ]);


        $this->addForeignKey('fk_id_invoice', 'invoiceProduct', 'id_invoice', 'invoices', 'id');
        $this->addForeignKey('fk_id_product', 'invoiceProduct', 'id_product', 'products', 'id');
    }

    public function safeDown()
    {
        $this->dropTable('invoiceProduct');
    }

}
