<?php

use yii\db\Migration;

class m200710_020203_create_table_products extends Migration
{
    public function safeUp()
    {
        $this->createTable('products', [
            'id' => $this->primaryKey(),
            'name' => $this->string(30)->notNull(),
            'price' => $this->decimal(10,2)->notNull(),
            'quantity' => $this->smallInteger(4)->defaultValue(0),
        ]);
    }

    public function safeDown()
    {
        $this->dropTable('products');
    }


}
