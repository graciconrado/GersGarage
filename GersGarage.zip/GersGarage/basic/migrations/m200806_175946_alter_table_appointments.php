<?php

use yii\db\Migration;

class m200806_175946_alter_table_appointments extends Migration
{
    public function safeUp()
    {
        $this->addColumn('appointments','id_service',$this->integer(20));

        $this->addForeignKey('fk_app_serv', 'appointments', 'id_service','services', 'id');
    }

    public function safeDown()
    {
        $this->dropColumn('appointments', 'id_service');
    }
}
