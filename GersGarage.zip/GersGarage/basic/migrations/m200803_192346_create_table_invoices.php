<?php

use yii\db\Migration;

class m200803_192346_create_table_invoices extends Migration
{
    public function safeUp()
    {
        $this->createTable('invoices', [
            'id' => $this->primaryKey(),
            'date' => $this->date()->notNull(),
            'id_employee' => $this->integer(11)->notNull(),
            'id_appointment' => $this->integer(11),
            'total' => $this->integer(11)->notNull(),
            'customerName' => $this->string(50)->null(),
        ]);

        $this->addForeignKey('fk_id_appointment', 'invoices', 'id_appointment', 'appointments', 'id');
        $this->addForeignKey('fk_id_employee', 'invoices', 'id_employee', 'users', 'userId');
    }

    public function safeDown()
    {
        $this->dropTable('invoices');
    }
}
