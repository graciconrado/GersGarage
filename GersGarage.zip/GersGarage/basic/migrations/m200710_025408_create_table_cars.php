<?php

use yii\db\Migration;

class m200710_025408_create_table_cars extends Migration
{
    public function safeUp()
    {
        $this->createTable('cars', [
            'id' => $this->primaryKey(),
            'license' => $this->string(9)->notNull()->unique(),
            'vehicle_type' => $this->string(15)->notNull(),
            'maker' => $this->string(15)->notNull(),
            'model' => $this->string(15)->notNull(),
            'engine_type' => $this->string(15)->notNull(),
            'userId' => $this->integer()->notNull(),
        ]);

        $this->addForeignKey('fk_car_user', 'cars', 'userId','users', 'userId');

    }

    public function safeDown()
    {
        $this->dropTable('cars');
    }
}
