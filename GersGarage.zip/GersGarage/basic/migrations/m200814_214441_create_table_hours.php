<?php

use yii\db\Migration;

/**
 * Class m200814_214441_create_table_hours
 */
class m200814_214441_create_table_hours extends Migration
{
    /**
     * {@inheritdoc}
     */
    public function safeUp()
    {
        $this->createTable('hour',[
            'hour' => $this->string(5)->notNull(),
        ]);

        $this->addPrimaryKey('pk_hour','hour','hour');

        $this->insert('hour',['hour' => '08:00']);
        $this->insert('hour',['hour' => '09:00']);
        $this->insert('hour',['hour' => '10:00']);
        $this->insert('hour',['hour' => '11:00']);
        $this->insert('hour',['hour' => '12:00']);
        $this->insert('hour',['hour' => '13:00']);
        $this->insert('hour',['hour' => '14:00']);
        $this->insert('hour',['hour' => '15:00']);
        $this->insert('hour',['hour' => '16:00']);
    }

    /**
     * {@inheritdoc}
     */
    public function safeDown()
    {
        echo "m200814_214441_create_table_hours cannot be reverted.\n";

        return false;
    }

    /*
    // Use up()/down() to run migration code without a transaction.
    public function up()
    {

    }

    public function down()
    {
        echo "m200814_214441_create_table_hours cannot be reverted.\n";

        return false;
    }
    */
}
