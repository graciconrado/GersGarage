<?php

use yii\db\Migration;


class m200813_111216_create_table_services extends Migration
{
    public function safeUp()
    {
        $this->createTable('services', [
            'id' => $this->primaryKey(),
            'name' => $this->string(30)->notNull(),
            'price' => $this->decimal(10,2)->notNull(),
        ]);

        $this->insert('services',['name' => 'Interim Service', 'price' => '250']);
        $this->insert('services',['name' => 'Major Service', 'price' =>'400']);
        $this->insert('services',['name' => 'Repair/Fault', 'price' => '150']);
        $this->insert('services',['name' => 'Major Repair','price' => '500']);


    }

    public function safeDown()
    {
        $this->dropTable('services');
    }
}
