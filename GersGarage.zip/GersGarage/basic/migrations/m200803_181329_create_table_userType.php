<?php

use yii\db\Migration;

class m200803_181329_create_table_userType extends Migration
{
    public function safeUp()
    {
        $this->createTable('userType', [
            'id' => $this->primaryKey(),
            'type' => $this->string(20)->notNull(),
        ]);

        $this->insert('userType', [
            'type' => 'admin',
        ]);

        $this->insert('userType', [
        'type' => 'mechanic',
        ]);

        $this->insert('userType', [
        'type' => 'user',
        ]);
    }

    public function safeDown()
    {
        $this->dropTable('userType');
    }
}
