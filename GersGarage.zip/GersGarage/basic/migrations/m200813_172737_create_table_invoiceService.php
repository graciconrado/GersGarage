<?php

use yii\db\Migration;


class m200813_172737_create_table_invoiceService extends Migration
{
    public function safeUp()
    {
        $this->createTable('invoiceService', [
            'id' => $this->primaryKey(),
            'id_invoice' => $this->integer(11)->notNull(),
            'id_service' => $this->integer(11)->notNull()
        ]);

        $this->addForeignKey('fk_invoiceService_invoice', 'invoiceService', 'id_invoice', 'invoices', 'id');
        $this->addForeignKey('fk_invoiceService_service', 'invoiceService', 'id_service', 'services', 'id');
    }

    public function safeDown()
    {
        $this->dropTable('invoiceService');
    }

}
