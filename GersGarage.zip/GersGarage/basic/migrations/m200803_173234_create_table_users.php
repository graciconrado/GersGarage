<?php

use app\models\User;
use yii\db\Migration;


class m200803_173234_create_table_users extends Migration
{
    public function safeUp()
    {
        $this->createTable('users', [
            'userId' => $this->primaryKey(),
            'firstName' => $this->string(40)->notNull(),
            'surname' => $this->string(40)->notNull(),
            'password' => $this->string(64)->notNull(),
            'birthday' => $this->date()->notNull(),
            'email' => $this->string(40)->notNull()->unique(),
            'phone' => $this->string(20)->notNull(),
            'userType' => $this->integer(11)->defaultValue(User::$CUSTOMER_TYPE)->notNull(),
            'status' => $this->integer(11)->defaultValue(1)->notNull(),
        ]);

        $this->addForeignKey('fk_id_userType', 'users', 'userType', 'userType', 'id');
    }

    public function safeDown()
    {
        $this->dropTable('users');
    }
}
