<?php

use yii\db\Migration;

class m200806_133746_alter_table_appointments extends Migration
{

    public function safeUp()
    {
        $this->addColumn('appointments','time',$this->time());
    }

    public function safeDown()
    {
        $this->dropColumn('appointments', 'time');
    }

}
