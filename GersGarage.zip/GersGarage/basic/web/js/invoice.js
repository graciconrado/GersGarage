//REF: https://stackoverflow.com/questions/30876089/clone-table-row-and-increment-ids-by-1/30876292

function changeProd(newProd){
    var line = $(newProd).data('line');
    var selectedPrice = $(newProd). children("option:selected").data('price');
    var total = parseInt($('#qtt_' + line).val()) * selectedPrice;

    total = total.toFixed(2);

    if(!isNaN(total)){
        $('#prodTotal_' + line).html(total);
        $('#prodTotal_' + line).data('total', total);

    }else{
        $('#prodTotal_' + line).html('-');
        $('#prodTotal_' + line).data('total', 0);
    }

    updateInvTotal();
}

function changeQtt(newQtt){
    var line = $(newQtt).data('line');
    var selectedQtt = $(newQtt).val();

    var selectedPrice = $('#prod_' + line). children("option:selected").data('price');

    var total = selectedQtt * selectedPrice;

    total = total.toFixed(2);

    if(!isNaN(total)){
        $('#prodTotal_' + line).html(total);
        $('#prodTotal_' + line).data('total', total);
    }else{
        $('#prodTotal_' + line).html('-');
        $('#prodTotal_' + line).data('total', 0);
    }
    updateInvTotal();
}

$('#addRow').click(function () {

    var line = $('#product_table tr:last').clone();

    $('#product_table tr:last').after(line);

    $('#product_table tbody tr.prod_line').each(function (i) {
        $(this).attr('id', i);
        $(this).find('select.product_select').attr('id', 'prod_' + i);
        $(this).find('select.product_select').attr('data-line', i);
       $(this).find('select.product_select').attr('name', 'InvoiceProduct[line_' + i + '][id_product]');

        $(this).find('input.product_qtt').attr('id', 'qtt_' + i);
        $(this).find('input.product_qtt').attr('data-line', i);
       $(this).find('input.product_qtt').attr('name', 'InvoiceProduct[line_' + i + '][quantItem]');

        $(this).find('td.total_cell').attr('id', 'prodTotal_' + i);

    });
    $('#product_table tr:last').find('input.product_qtt').val(0);
    $('#product_table tr:last').find('td.total_cell').html('-');

});


function updateInvTotal()
{
    var newTotal = 0;
    $('#product_table tbody td.total_cell').each(function (i) {
        newTotal = newTotal + parseFloat($(this).data('total'));
    });

    var servPrice = $('#servPrice').data('price');

    if(isNaN(servPrice)){
        servPrice = 0;
    }

    newTotal = newTotal + parseFloat(servPrice);

    $('#invoice-total').val(newTotal.toFixed(2));
}


//REF = https://www.w3schools.com/jquery/jquery_ajax_get_post.asp
function getAppDetails(selectedApp){
    var appId = $(selectedApp).children("option:selected").val();

    var url = $(selectedApp).data('url');
    var csrf = $(selectedApp).data('csrf');

    $.post(url,
        {
            appId: appId,
            YII_APP_CSRF:csrf,
        },
        function(data, status){
            if(data.success){
                $('#invoice-customername').val(data.customer);
                $('#servName').html(data.serviceName);
                $('#servPrice').html(data.servicePrice);
                $('#servPrice').data('price', data.servicePrice);

                updateInvTotal();
            }
        });
}