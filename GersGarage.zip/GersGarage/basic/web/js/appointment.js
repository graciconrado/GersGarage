function getHours(selectedDate){
    var date = $(selectedDate).val();
    var url = $(selectedDate).data('url');
    var csrf = $(selectedDate).data('csrf');

    $.post(url,
        {
            date: date,
            YII_APP_CSRF:csrf,
        },
        function(data, status) {
            $('#appointments-time')
                .find('option')
                .remove()
                .end()
                .append(data)
                .val('whatever')
            ;
        });

}