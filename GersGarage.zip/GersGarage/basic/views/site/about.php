<?php

/* @var $this yii\web\View */

use yii\helpers\Html;

?>
<div class="site-about">
    <h1><?= Html::encode($this->title) ?></h1>
</div>

<div class="site-about px-3 py-3 pt-md-5 pb-md-4 mx-auto text-justify">
    <p>Ger’s Garage carries out car servicing and repairs on all makes and models of vehicles including Audi,
        BMW, Citroen, Fiat, Ford, Honda, Hyundai, Jaguar, Kia, Land Rover, Mazda, Mercedes, Nissan, Opel,
        Peugeot, Renault, Saab, Skoda, Toyota, Volkswagen, Volvo and many more. Also motorcycle, small vans
        and buses.</p>
    <p>We guarantee that our work is conducted to the highest of standards by our fully qualified and
        experienced mechanics, panel beaters and spray painters.</p>
    <p>We pride ourselves on  quality of service we provide to you the customer and we know how important
        your car is in your day to day life. We make sure all our work is conducted to your highest
        expectations.</p>
    <p>You might try to save money by getting your car serviced less regularly. But cutting back on
        essential maintenance and repairs does not always save you money in the long run. Having your car
        serviced regularly will help keep your car in the best working order and will help you budget for
        upcoming maintenance, like new tyres. Each model of car has a manufacturer’s recommended time frame
        for routine servicing and you should try to service your car as frequently as recommended to keep
        it in its best condition.</p>

</div>

    <div class="pricing-header px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
        <h1 class="display-4">Services</h1>
    </div>

    <div class="container">
        <div class="card-deck mb-3 text-center">
            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <h4 class="my-0 font-weight-normal">Interim Service</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title pricing-card-title">€250</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li>An interim service focuses on the elements of your car that need more regular attention and should usually happen every six months or 10,000 Kms (6,000 miles).</li>
                    </ul>
                    <button type="button" class="btn btn-lg btn-block btn-info">Book Now</button>
                </div>
            </div>
            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <h4 class="my-0 font-weight-normal">Major Service</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title pricing-card-title">€400</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li>A major service should ideally take place once a year or every 20,000 Kms (12,000 miles) in order to give you the best chance of trouble free motoring.</li>
                    </ul>
                    <button type="button" class="btn btn-lg btn-block btn-info">Book Now</button>
                </div>
            </div>

            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <h4 class="my-0 font-weight-normal">Repair/Fault</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title pricing-card-title">from €150</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li>Repairs and faults include crash repairs, panel beating, spray painting, full resprays, dents and dings, key scratches, scuffs and bumps, and others.</li>
                    </ul>
                    <button type="button" class="btn btn-lg btn-block btn-info">Book Now</button>
                </div>
            </div>
            <div class="card mb-4 shadow-sm">
                <div class="card-header">
                    <h4 class="my-0 font-weight-normal">Major Repair</h4>
                </div>
                <div class="card-body">
                    <h1 class="card-title pricing-card-title">from €500</h1>
                    <ul class="list-unstyled mt-3 mb-4">
                        <li>A major repair includes checking or replacing all panels, parking sensors, major bump repair, insurance claims and restorations.</li>
                    </ul>
                    <button type="button" class="btn btn-lg btn-block btn-info">Book Now</button>
                </div>
            </div>
        </div>

    </div>


</div>
