<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap4\ActiveForm */
/* @var $model app\models\RegisterForm */

use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;
use yii\captcha\Captcha;

?>
<div class="site-register">
    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        Please fill out the following form to register on the system and make an appointment with us.
        Thank you!
    </p>

    <div class="row">
        <div class="col-lg-5">

            <?php if($model->hasErrors()):?>
                <div class="alert alert-danger">
                    Please fix the following errors:
                    <ul>
                        <?php foreach($model->getErrorSummary(true) as $error):?>
                            <li><?=$error?></li>
                        <?php endforeach;?>
                    </ul>
                </div>
            <?php endif;?>

            <?php $form = ActiveForm::begin(['id' => 'register-form']); ?>

            <?= $form->field($model, 'firstName')->textInput(['autofocus' => true]) ?>

            <?= $form->field($model, 'surname') ?>

            <?= $form->field($model, 'email') ?>

            <?= $form->field($model, 'birthday')->input('date')?>

            <?= $form->field($model, 'phone') ?>

            <?= $form->field($model, 'password')->passwordInput()?>

            <?= $form->field($model, 'verifyCode')->widget(Captcha::className(), [
                    'template' => '<div class="row"><div class="col-lg-3">{image}</div><div class="col-lg-6">{input}</div></div>',
                ]) ?>

            <div class="form-group">
                <?= Html::submitButton('Submit', ['class' => 'btn btn-primary', 'name' => 'register-button']) ?>
            </div>

            <?php ActiveForm::end(); ?>

        </div>
    </div>

</div>

