<div class="text-center">
    <div class="cover-container d-flex w-100 h-100 p-3 mx-auto flex-column">

        <main role="main" class="inner cover">
            <h1 class="cover-heading">Enjoy your way.</h1>

            <p class="lead">Let us take care of your car so you can enjoy your trip without worries. Book an appointment now!</p>
            <p class="lead">
                <a href="/site/login" class="btn btn-lg btn-info">Book here</a>
            </p>
        </main>

    </div>
</div>


