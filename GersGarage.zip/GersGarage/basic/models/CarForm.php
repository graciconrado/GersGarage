<?php

namespace app\models;

use Yii;
use yii\base\Model;

/**
 * CarForm is the model behind the My Cars.
 */
class CarForm extends Model
{
    public $license;
    public $vehicle_type;
    public $maker;
    public $model;
    public $engine_type;


    /**
     * @return array the validation rules.
     */
    public function rules()
    {
        return [
            // license, vehicle_type, maker, model and engine_type are required
            [['license', 'vehicle_type', 'maker', 'model', 'engine_type'], 'required'],
        ];
    }



    public function registerCar()
    {
        $newCar = new Cars();

        $newCar->license = $this->license;
        $newCar->vehicle_type = $this->vehicle_type;
        $newCar->maker = $this->maker;
        $newCar->model = $this->model;
        $newCar->engine_type = $this->engine_type;

        return $newCar->save();
    }
}