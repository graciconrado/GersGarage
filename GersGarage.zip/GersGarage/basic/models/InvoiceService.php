<?php


namespace app\models;


use yii\db\ActiveRecord;

class InvoiceService extends ActiveRecord
{
    public static function tableName()
    {
        return "invoiceservice";
    }

}