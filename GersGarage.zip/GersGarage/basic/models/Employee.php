<?php


namespace app\models;

class Employee extends User
{
    public static function getMechanicList()
    {
        $mechs = self::find()->where([
            'userType' => self::$MECHANIC_TYPE,
            'status' => 1
        ])->all();
        $mechList = [];

        foreach ($mechs as  $mech){
            $mechList[$mech->userId] = $mech->firstName.' '.$mech->surname;
        }

        return $mechList;

    }

    public function getAppointments()
    {
        return $this->hasMany(Appointments::class,['id_mechanic' => 'userId']);
    }

    public function hasAppointment()
    {
        $apps = $this->getAppointments()->all();

        return count($apps) > 0;
    }

}