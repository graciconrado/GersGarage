<?php


namespace app\models;


use yii\db\ActiveRecord;

class Hour extends ActiveRecord
{
    public static function getHours()
    {
        return self::find()->all();
    }

    public static function getListHours($validated = true, $date)
    {
        $hours = self::getHours();
        $hourList = [];
        $mechanicNumber = Employee::find()->where([
            'userType' =>User::$MECHANIC_TYPE ,
            'status' => 1,
        ])->count();
        foreach ($hours as $hour){
            $apps = Appointments::find()->where([
                'date' => $date,
                'time' => $hour->hour
            ])->count();

            if($validated){
                if($apps < $mechanicNumber){
                    $hourList[$hour->hour] = $hour->hour;
                }
            }else{
                $hourList[$hour->hour] = $hour->hour;
            }


        }

        return $hourList;

    }

}