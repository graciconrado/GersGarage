<?php

namespace app\models;

use yii\db\ActiveRecord;


/**
 * Class Service
 * @package app\models
 *
 * @property int id
 * @property string name
 * @property int price
 *
 */


class Service extends ActiveRecord
{
    public function rules()
    {
        return [
            [[ 'name', 'price'], 'required'],
            [['price'], 'number', 'min' => 0.01]
        ];
    }

    public static function tableName()
    {
        return 'services';
    }

    public function getInvoices()
    {
        return $this->hasMany(Invoice::class,['id' => 'id_invoice'])->
        viaTable( 'invoiceservice', ['id_service' => 'id']);
    }

    public static function getList()
    {
        $services = self::find()->all();

        $serviceList = [];

        foreach ($services as $service){
            $serviceList[$service->id] = $service->name;
        }

        return $serviceList;
    }

    public function getAppointments()
    {
        return $this->hasMany(Appointments::class, ['id_service' =>'id']);
    }

    public function hasRelations()
    {
        $invoices = $this->getInvoices()->all();

        $appointments = $this->getAppointments()->all();

        return count($invoices) > 0 || count($appointments) > 0;
    }

}
