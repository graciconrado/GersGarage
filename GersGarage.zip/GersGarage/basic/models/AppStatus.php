<?php


namespace app\models;


use yii\db\ActiveRecord;

class AppStatus extends ActiveRecord
{
    public static $STATUS_BOOKED = 1;
    public static $STATUS_CANCELED = 6;
    public static $STATUS_FIXED = 3;

    public static function tableName()
    {
        return 'appStatus';
    }

    public static function getList()
    {
        $allStatus = self::find()->all();
        $statusList = [];
        foreach ($allStatus as $status){
            $statusList[$status->id] = $status->status;
        }

        return $statusList;
    }

    public function getStatus($id)
    {
        $status = self::findOne(['id' => $id]);

        return $status->status;
    }

    public function getAppointments()
    {
        return $this->hasMany(Appointments::class, ['status' => 'id']);
    }




}