<?php

namespace app\models;

use yii\db\ActiveRecord;


/**
 * Class Product
 * @package app\models
 *
 * @property int id
 * @property string name
 * @property int price
 * @property int quantity
 *
 */


class Product extends ActiveRecord
{
    public static function tableName()
    {
        return 'products';
    }

    public function rules()
    {
        return [
          [[ 'name', 'price', 'quantity'], 'required'],
          [['quantity'], 'number', 'min' => 0],
          [['price'], 'number', 'min' => 0.01]
        ];
    }

    public function getInvoices()
    {
        return $this->hasMany(Invoice::class,['id' => 'id_invoice'])->
            viaTable( 'invoiceproduct', ['id_product' => 'id']);
    }

    public function getInvoiceProduct()
    {
        return $this->hasMany(InvoiceProduct::class,['id_product' => 'id']);
    }

    public function hasInvoice()
    {
        $invoices = $this->getInvoiceProduct()->count();

        return $invoices > 0;
    }

    public static function getList()
    {
        $products = self::find()->all();
        $productList = [];
        foreach ($products as $product){
            $productList[$product->id] = $product->name;
        }

        return $productList;
    }

}