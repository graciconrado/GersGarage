<?php


namespace app\models;


use yii\db\ActiveRecord;

/**
 * Class Appointments
 * @package app\models
 *
 * @property int id
 * @property string date
 * @property int status
 * @property string comment
 * @property int id_customer
 * @property int id_car
 * @property int id_mechanic
 * @property string time
 * @property string service
 *
 */

class Appointments extends ActiveRecord
{

    public function getStatusLabel($status)
    {
        return self::$LABELS[$status];
    }

    public function rules()
    {
        return [
            // date, id_car, time and service are required
            [['date', 'id_car', 'time', 'id_service', 'id_customer', 'status'], 'required'],
            [['comment', 'id_mechanic', 'id'], 'safe'],
            [['date'], 'validateDate'],
        ];
    }

    public function validateDate($attribute, $params)
    {
        if (!$this->hasErrors()) {

            $mechanicNumber = Employee::find()->where([
                'userType' =>User::$MECHANIC_TYPE ,
                'status' => 1,
            ])->count();

            $maxAppointimentsDay =  $mechanicNumber * 4;

            $apps = self::find()->where(['date' => $this->date])->count();

            if($apps >= $maxAppointimentsDay){
                $this->addError($attribute, 'Sorry, there is not avaiable appointment to '. $this->date);
            }
        }
    }

    public function getCar()
    {
        return $this->hasOne(Cars::class, ['id' => 'id_car']);
    }

    public function attributeLabels()
    {
        return [
            'id_car' => 'Selected vehicle',
            'id_service' => 'Service',
        ];
    }

    public function getAppStatus()
    {
        return $this->hasOne(AppStatus::class, ['id' => 'status']);
    }

    public function getCustomer()
    {
        return $this->hasOne(User::class,['userId' => 'id_customer']);
    }

    public function getMechanic()
    {
        return $this->hasOne(User::class, ['userId' => 'id_mechanic']);
    }

    public function getService()
    {
        return $this->hasOne(Service::class, ['id' => 'id_service']);
    }

    public static function getList($status = false, $noInvoice = false)
    {
        $query = self::find();

        if($status){
            $query->andwhere(['status' => $status]);
        }

        $apps = $query->all();
        $appsList = [];

        foreach ($apps as $app){
            if($noInvoice){
                if(!$app->hasInvoice()){
                    $appsList[$app->id] = $app->date.'-'.$app->time.' / '.$app->customer->firstName.' '.$app->customer->surname;
                }
            }else{
                $appsList[$app->id] = $app->date.'-'.$app->time.' / '.$app->customer->firstName.' '.$app->customer->surname;
            }
        }

        return $appsList;
    }

    public function getInvoice()
    {
        return $this->hasOne(Invoice::class, ['id_appointment' => 'id']);
    }

    public function hasInvoice()
    {
        $invoice = $this->getInvoice()->all();

        return count($invoice) > 0;
    }




}