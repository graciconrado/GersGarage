<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;


/**
 * Class Cars
 * @package app\models
 *
 * @property int id
 * @property string license
 * @property string vehicle_type
 * @property string maker
 * @property string model
 * @property string engine_type
 * @property int userId
 *
 */
class Cars extends ActiveRecord
{

    public function rules()
    {
        return [
            // license, vehicle_type, maker, model and engine_type are required
            [['license', 'vehicle_type', 'maker', 'model', 'engine_type', 'userId'], 'required'],
            [['license'], 'unique', 'message' => 'Car already exists. Contact the office.', 'on' => 'Insert'],
        ];
    }

    public function getAppointments()
    {
        return $this->hasMany(Appointments::class, ['id_car' => 'id']);
    }

    public function getUser()
    {
        return $this->hasOne(User::class, ['userId' => 'userId']);
    }

    public function hasAppointment()
    {
        $appointments = $this->getAppointments()->all();

        return count($appointments) > 0;
    }

    public static function getCarList($userId = false)
    {
        $query = self::find();

        if($userId){
            $query->where(['userID' => $userId]);
        }

        $cars = $query->all();

        $carsList = [];

        foreach ($cars as $car){
            $carsList[$car->id] = $car->license.' - '.$car->maker.' - '.$car->model;
        }

        return $carsList;
    }


}