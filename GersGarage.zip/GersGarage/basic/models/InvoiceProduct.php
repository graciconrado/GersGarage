<?php


namespace app\models;


use yii\db\ActiveRecord;

class InvoiceProduct extends ActiveRecord
{
    public function rules()
    {
        return[
//            [['id_invoice', 'id_product','quantItem'], 'required'],
            [['quantItem'], 'number', 'min' => 1],

        ];
    }

    public static function tableName()
    {
        return "invoiceproduct";
    }

    public function getProduct()
    {
        return $this->hasOne(Product::class, ['id' => 'id_product']);
    }

}