<?php

namespace app\models;

use Yii;
use yii\db\ActiveRecord;

/**
 * Class User
 * @package app\models
 *
 * @property int userId
 * @property string firstName
 * @property string surname
 * @property string password
 * @property string birthday
 * @property string email
 * @property string phone
 * @property int userType
 * @property int status
 *
 */
class User extends ActiveRecord implements \yii\web\IdentityInterface
{
    public static $PASSWORD_SALT = "dfadkjfhdaskjadsf";
    public static $CUSTOMER_TYPE = 3;
    public static $ADMIN_TYPE = 1;
    public static $MECHANIC_TYPE = 2;

    public static $TYPE_LIST = [
        '1' => 'Administrator',
        '2' => 'Mechanic',
        '3' => 'Customer',
    ];


    public static $STATUS_ACTIVE = 1;
    public static $STATUS_INACTIVE = 0;

    public function rules()
    {
        return [
            [['firstName', 'surname', 'password', 'birthday', 'email','phone','userType', 'status'],'required'],
            ['email', 'email'],
            [['email'], 'verifyEmail'],
        ];
    }

    public function verifyEmail($attribute, $params)
    {
        if (!$this->hasErrors()) {
            if($this->userId) {
                $otherUser = self::find()->where(
                'email = "'.$this->email.'" and userId !='.$this->userId
                )->one();
            }else{
                $otherUser = self::find()->where([
                    'email' => $this->email
                ])->one();
            }

            if($otherUser){
                $this->addError($attribute, 'This email is already in use');
            }

        }

    }

    /**
     * {@inheritdoc}
     */
    public static function findIdentity($id)
    {
        if(Yii::$app->getSession()->has('user-'.$id)){
            return new self(Yii::$app->getSession()->get('user-'.$id));
        }

        return self::findOne([
            'userId' => $id,
        ]);
    }

    public static function tableName()
    {
        return 'users';
    }

    /**
     * {@inheritdoc}
     */
    public static function findIdentityByAccessToken($token, $type = null){}

    /**
     * {@inheritdoc}
     */
    public function getId()
    {
        return $this->userId;
    }

    /**
     * {@inheritdoc}
     */
    public function getAuthKey(){}

    /**
     * {@inheritdoc}
     */
    public function validateAuthKey($authKey)
    {
        return $this->authKey === $authKey;
    }

    /**
     * Validates password
     *
     * @param string $password password to validate
     * @return bool if password provided is valid for current user
     */
    public function validatePassword($password)
    {
         return hash_equals($this->password, crypt($password, $this->password));
        //return $this->password === $password;
    }

    public static function findUserByEmail($email)
    {
        return self::findOne(['email' => $email]);
    }

    public static function getAdminByEmail($email)
    {
        return self::findOne([
            'email' => $email,
            'userType' => 1,
        ]);
    }

    public function getCars()
    {
        return $this->hasMany(Cars::class,['userId' => 'userId']);
    }

    public static function getList($type)
    {
        $query = User::find()->where(['status' => 1]);

        if($type){
            $query->andWhere(['userType' => $type]);
        }

        $users = $query->all();
        $userList = [];

        foreach ($users as $user){
            $userList[$user->userId] = $user->firstName.' '.$user->surname.' - '.$user->email;
        }

        return $userList;


    }






}
