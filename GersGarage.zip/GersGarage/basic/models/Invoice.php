<?php

namespace app\models;

use yii\db\ActiveRecord;

/**
 * Class Invoice
 * @package app\models
 *
 * @property int id
 * @property int id_appointment
 * @property int id_product
 * @property int quantity
 * @property int id_employee
 *
 */

class Invoice extends ActiveRecord
{
    public static function tableName()
    {
        return 'invoices';
    }

    public function rules()
    {
        return [
            [[ 'date', 'id_employee', 'total'], 'required'],
            [[ 'id_appointment', 'customerName', 'products'], 'safe'],
            [['total'], 'number', 'min' => 0.01]
        ];
    }

//    public function getProducts()
//    {
//        return $this->hasMany(Product::class,['id' => 'id_product'])->
//        viaTable( 'invoiceproduct', ['id_invoice' => 'id']);
//    }

    public function getProductItems()
    {
        return $this->hasMany(InvoiceProduct::class,['id_invoice' => 'id']);
    }

    public function getServices()
    {
        return $this->hasMany(Service::class,['id' => 'id_service'])->
        viaTable( 'invoiceservice', ['id_invoice' => 'id']);
    }

    public function hasItems()
    {
        $services = $this->getAppointment()->all();
        $products = $this->getProductItems()->all();

        return count($services) > 0 || count($products) > 0;
    }

    public function getCreatedBy()
    {
        return $this->hasOne(User::class,['userId' => 'id_employee']);
    }

    public function getAppointment()
    {
        return $this->hasOne(Appointments::class, ['id' => 'id_appointment']);
    }
}
