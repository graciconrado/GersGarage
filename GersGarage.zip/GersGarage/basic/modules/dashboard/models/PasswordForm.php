<?php
namespace app\modules\dashboard\models;

use app\models\User;
use yii\base\Model;

class PasswordForm extends Model
{
    public $oldPass;
    public $userId;
    public $newPass;
    public $confirmPass;

    public function rules()
    {
        return [
            [['oldPass','newPass','confirmPass', 'userId'], 'required'],
            ['confirmPass', 'compare', 'compareAttribute'=>'newPass', 'message'=>"Passwords don't match" ],
        ];
    }

    public function savePassword()
    {

        $user = User::findOne(['userId' => $this->userId]);

        if($user && $user->validatePassword($this->oldPass)){
            $user->password = crypt($this->newPass, User::$PASSWORD_SALT);

            return $user->save();
        }

        return false;

    }

    public function attributeLabels()
    {
        return [
          'oldPass' => 'Old password',
          'newPass' => 'New password',
          'confirmPass' => 'Repeat  password',
        ];
    }

}