<?php


namespace app\modules\dashboard;


use yii\base\Module;

class DashboardModule extends Module
{
    public function init()
    {
        parent::init();
    }

}