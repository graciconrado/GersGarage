<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap4\ActiveForm */
/* @var $model app\models\User */

use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;

?>
<div class="site-profile">

    <div class="row">
        <div class="col-md-6 col-sm-12">
            <?php if($model->hasErrors()):?>
                <div class="alert alert-danger">
                    Please fix the following errors:
                    <ul>
                        <?php foreach($model->getErrorSummary(true) as $error):?>
                            <li><?=$error?></li>
                        <?php endforeach;?>
                    </ul>
                </div>
            <?php endif;?>
            <?php if($saved == true):?>
            <div class="alert alert-success">
                New password saved!
            </div>
            <?php endif;?>

            <?php $form = ActiveForm::begin(['id' => 'update-form']); ?>

            <?= $form->field($model, 'userId')->hiddenInput(['value' => Yii::$app->user->id])->label(false)?>

            <?= $form->field($model, 'oldPass')->passwordInput(['autofocus' => true]) ?>

            <?= $form->field($model, 'newPass')->passwordInput()?>

            <?= $form->field($model, 'confirmPass')->passwordInput()?>

            <div class="form-group">
                <?= Html::submitButton('Submit', ['class' => 'btn btn-primary', 'name' => 'update-button']) ?>
            </div>

            <?php ActiveForm::end(); ?>

        </div>
    </div>

</div>
