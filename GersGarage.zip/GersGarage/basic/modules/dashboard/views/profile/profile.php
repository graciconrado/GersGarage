<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap4\ActiveForm */
/* @var $model app\models\User */

use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;

?>
<div class="site-profile">

    <p>
        Please fill out the following form to update your personal information.
        Thank you!
    </p>

    <div class="row">
        <div class="col-md-6 col-sm-12">
            <?php if($user->hasErrors()):?>
                <div class="alert alert-danger">
                    Please fix the following errors:
                    <ul>
                        <?php foreach($user->getErrorSummary(true) as $error):?>
                            <li><?=$error?></li>
                        <?php endforeach;?>
                    </ul>
                </div>
            <?php endif;?>

            <?php $form = ActiveForm::begin(['id' => 'update-form']); ?>

            <?= $form->field($user, 'firstName')->textInput(['autofocus' => true]) ?>

            <?= $form->field($user, 'surname') ?>

            <?= $form->field($user, 'email') ?>

            <?= $form->field($user, 'birthday')->input('date') ?>

            <?= $form->field($user, 'phone')->textInput(['maxlength' => 20]) ?>

            <div class="form-group">
                <?= Html::submitButton('Submit', ['class' => 'btn btn-primary', 'name' => 'update-button']) ?>
            </div>

            <?php ActiveForm::end(); ?>

        </div>
    </div>

</div>
