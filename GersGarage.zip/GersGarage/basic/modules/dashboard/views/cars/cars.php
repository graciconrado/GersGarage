<?php

/* @var $this yii\web\View */

use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\helpers\Html;

?>

<div class="site-index container">
    <div class="row">
        <?= GridView::widget([
            'dataProvider' => $dataProvider,
            'options' => [
                'class' => 'table table-stripe table-hover'
            ],
            'columns' => [
                'license',
                'vehicle_type',
                'maker',
                'model',
                'engine_type',
                [
                    'class' => ActionColumn::class,
                    'header' => 'Options',
                    'buttons' => [
                        'update' => function($url, $row){
                            return '<form action="/dashboard/cars/update" class="float-left" method="post">
                                        <input type="hidden" name="_csrf" value="'.Yii::$app->request->csrfToken.'">
                                        <input type="hidden" name="carId" value="'.$row->id.'">
                                        <input type="submit" class="btn btn-primary" value="Update"> 
                                    </form>';
                        },
                        'delete' => function($url, $row){
                            if(!$row->hasAppointment()){
                                return '<form action="/dashboard/cars/delete" class="float-left" method="post">
                                        <input type="hidden" name="_csrf" value="'.Yii::$app->request->csrfToken.'">
                                        <input type="hidden" name="carId" value="'.$row->id.'">
                                        <input type="submit" 
                                               class="btn btn-danger" 
                                               value="Delete"
                                               data-confirm="Are you sure that you want to delete this car?"
                                       > 
                                    </form>';
                            }
                        },
                    ]
                    // you may configure additional properties here
                ],
            ]
        ]);?>
    </div>
    <a href="/dashboard/cars/insert" class="btn btn-success">New car</a>

</div>


