<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap4\ActiveForm */
/* @var $model app\models\RegisterForm */

use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;

?>
<div class="site-cars">

    <p>
        Please fill out the following form to register your car information.
    </p>

    <div class="row">
        <div class="col-lg-5">
            <?php if($model->hasErrors()):?>
                <div class="alert alert-danger">
                    Please fix the following errors:
                    <ul>
                        <?php foreach($model->getErrorSummary(true) as $error):?>
                            <li><?=$error?></li>
                        <?php endforeach;?>
                    </ul>
                </div>
            <?php endif;?>

            <?php $form = ActiveForm::begin(['id' => 'car-form']); ?>
            <?= $form->field($model,'userId')->hiddenInput(['value' => Yii::$app->user->id])->label(false)?>

            <?= $form->field($model, 'license')->textInput(['autofocus' => true]) ?>

            <?= $form->field($model, 'vehicle_type')->dropDownList([
                    'CAR' => 'CAR',
                    'MOTORCICLE' => 'MOTORCICLE',
                    'SUV' => 'SUV',
                    'MINIVAN' => 'MINIVAN',
                    'PICKUP' => 'PICKUP',
                    'CAMPERVAN' => 'CAMPERVAN',
                    'MINI TRUCK' => 'MINI TRUCK',
                    'MINI BUS' => 'MINI BUS',
                    'OTHER' => 'OTHER'
                    ]) ?>

            <?= $form->field($model, 'maker')->dropDownList([
                    'TOYOTA' => 'TOYOTA',
                    'VOLKSWAGEN' => 'VOLKSWAGEN',
                    'MERCEDES' => 'MERCEDES',
                    'BMW' => 'BMW',
                    'HONDA' => 'HONDA',
                    'GM' => 'GM',
                    'FORD' => 'FORD',
                    'FIAT' => 'FIAT',
                    'NISSAN' => 'NISSAN',
                    'OTHER' => 'OTHER'
            ]) ?>

            <?= $form->field($model, 'model')->textInput()?>

            <?= $form->field($model, 'engine_type')->dropDownList([
                    'PETROL' => 'PETROL',
                    'GAS' => 'GAS',
                    'DIESEL' => 'DIESEL',
                    'HIBRID' => 'HIBRID',
                    'ELETRIC' => 'ELETRIC'
                ])?>

            <div class="form-group">
                <?= Html::submitButton('Submit', ['class' => 'btn btn-primary', 'name' => 'registerCar-button']) ?>
            </div>

            <?php ActiveForm::end(); ?>

        </div>
    </div>

</div>