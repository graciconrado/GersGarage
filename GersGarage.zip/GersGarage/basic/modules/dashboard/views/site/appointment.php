<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap4\ActiveForm */

use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;

?>

<div class="site-appointment">

    <p>Please fill out the following form to make a new appointment.</p>
    <p>If you have any different service request, please <a href="/site/contact">contact us</a>.</p>

    <div class="row">
        <div class="col-sm-12">
            <?php $form = ActiveForm::begin(['id' => 'appointment-form']); ?>
            <div class="col-md-6 col-sm-12">
                <?= $form->field($model, 'id')->hiddenInput()->label(false)?>
                <?= $form->field($model, 'id_service')->dropDownList($services)?>

                <?= $form->field($model, 'date')->input('date',[
                    'min' => date('Y-m-d', strtotime('+1day')),
                    'onchange' => 'getHours(this)',
                    'data-csrf' => Yii::$app->request->csrfToken,
                    'data-url' => $hour,
                ]) ?>

                <?= $form->field($model, 'time')->dropDownList([
                    '' => 'Select the date',
                ]) ?>

                <?= $form->field($model, 'id_car')->dropDownList($cars) ?>

                <?= $form->field($model, 'comment')->textarea()?>


                <div class="form-group">
                    <?= Html::submitButton('Submit', ['class' => 'btn btn-primary', 'name' => 'registerAppointment-button']) ?>
                </div>
            </div>
            <?php ActiveForm::end(); ?>
        </div>



    </div>


</div>

