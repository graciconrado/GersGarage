<?php


namespace app\modules\dashboard\controllers;


use app\models\Appointments;
use app\models\AppStatus;
use app\models\Cars;
use app\models\Service;
use Yii;
use yii\data\ActiveDataProvider;
use yii\filters\AccessControl;
use yii\helpers\Url;
use yii\web\Controller;

class SiteController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class'=> AccessControl::class,
                'rules' => [
                    [
                        'allow' => true,
                        'roles' => ['@']
                    ]
                ],
            ]
        ];
    }

    public function actionIndex()
    {
        $this->layout = 'main';
        $this->view->title = 'My Appointments';

        $dataProvider = new ActiveDataProvider([
            'query' => Appointments::find()->where(['id_customer' => Yii::$app->user->id]),
            'pagination' => [
                'pageSize' => 20,
            ],
            'sort' => false
        ]);

        return $this->render('index', [
            'appointments' => $dataProvider
        ]);
    }

    public function actionNewAppointment()
    {
        $this->layout = 'main';
        $this->view->title = 'New Appointment';

        $model = new Appointments();
        $carsList = ['' => 'Select'] + Cars::getCarList(Yii::$app->user->id);

        $serviceList = ['' => 'Select'] + Service::getList();

        if($model->load(Yii::$app->request->post())){
            $model->status = AppStatus::$STATUS_BOOKED;
            $model->id_customer = Yii::$app->user->id;

            if($model->validate()){
                $model->save();
                $this->redirect('/dashboard');
            }
        }

        return $this->render('appointment', [
            'model' => $model,
            'cars' => $carsList,
            'services' => $serviceList,
            'hour' => Url::to(['/admin/appointment/get-hours'], true),
        ]);
    }

    public function actionUpdate()
    {
        $this->layout = 'main';
        $this->view->title = 'My Appointments';

        $appointment = new Appointments();

        $appId = Yii::$app->request->post('appId');

        $carsList = ['' => 'Select'] +  Cars::getCarList(Yii::$app->user->id);

        $serviceList = ['' => 'Select'] + Service::getList();

        if($appId){
            $appointment = Appointments::findOne(['id' => $appId]);

            $appointment->time = date('H:i', strtotime($appointment->time));

            return $this->render('appointment', [
                'model' => $appointment,
                'cars' => $carsList,
                'services' => $serviceList,
                'hour' => Url::to(['/admin/appointment/get-hours'], true),
            ]);
        }

        if($appointment->load(Yii::$app->request->post())){
            $appointment = Appointments::findOne(['id' => $appointment->id]);
            if($appointment->load(Yii::$app->request->post()) && $appointment->validate()){
                $appointment->save();
            }

        }

        return $this->redirect('/dashboard/site/index');

    }

    public function actionCancel()
    {
        $this->layout = 'main';
        $this->view->title = 'My Appointments';

        $appointment = new Appointments();

        $appId = Yii::$app->request->post('appId');

        if($appId){
            $appointment = Appointments::findOne(['id' => $appId]);
            $appointment->status = AppStatus::$STATUS_CANCELED;
            $appointment->save();

        }

        return $this->redirect('/dashboard/site/index');


    }

}