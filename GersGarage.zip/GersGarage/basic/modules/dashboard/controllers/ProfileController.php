<?php

namespace app\modules\dashboard\controllers;

use app\models\User;
use app\modules\dashboard\models\PasswordForm;
use yii\web\Controller;
use Yii;

class ProfileController extends Controller
{
    public function actionIndex()
    {
        $this->layout = 'main';
        $this->view->title = 'My Profile';

        $user =  User::find()->where(['userId' => Yii::$app->user->id])->one();

        if($user->load(Yii::$app->request->post()) && $user->validate()){
            $user->save();
        }


        return $this->render('profile',[
            'user' => $user,
        ]);

    }

    public function actionChangePassword()
    {
        $this->layout = 'main';
        $this->view->title = 'Change password';
        $saved = false;

        $passForm = new PasswordForm();

        if($passForm->load(Yii::$app->request->post()) && $passForm->validate()){
            $saved = $passForm->savePassword();

            if($saved){
                $passForm = new PasswordForm();
            }
        }

        return $this->render('password',[
            'model' => $passForm,
            'saved' => $saved,
        ]);


    }

}