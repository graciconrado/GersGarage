<?php

namespace app\modules\dashboard\controllers;

use app\models\Cars;
use Yii;
use yii\data\ActiveDataProvider;
use yii\web\Controller;


class CarsController extends Controller
{
    public function actionIndex()
    {
        $this->layout = 'main';
        $this->view->title = 'My Cars';

        $cars = new ActiveDataProvider([
            'query' => Cars::find()->where(['userId' => Yii::$app->user->id]),
            'pagination' => [
                'pageSize' => 20,
            ],
            'sort' => false
        ]);

        return $this->render('cars', [
            'dataProvider' => $cars,
        ]);
    }

    public function actionInsert()
    {
        $this->layout = 'main';
        $this->view->title = 'My Cars';

        $model = new Cars();

        if($model->load(Yii::$app->request->post()) && $model->validate()){
            if($model->save()){
                return  $this->redirect('/dashboard/cars');
            }
        }

        return $this->render('insert', [
            'model' => $model,
        ]);
    }

    public function actionDelete()
    {
        $carId = Yii::$app->request->post('carId');

        $car = Cars::findOne(['id' => $carId]);

        if($car && !$car->hasAppointment()){
            $car->delete();
            return  $this->redirect('/dashboard/cars');
        }
    }

    public function actionUpdate()
    {
        $this->layout = 'main';
        $this->view->title = 'My Cars';

        $model = new Cars();
        $carId = Yii::$app->request->post('carId');



        if($carId){
            $model = Cars::findOne(['id' => $carId]);
        }

        $newData = Yii::$app->request->post('Cars') ?? [];

        if(isset($newData['id'])){
            $car = Cars::findOne(['id' => $newData['id']]);
            if($car->load(Yii::$app->request->post()) && $car->validate()){
                if($car->save()){
                    return  $this->redirect('/dashboard/cars');
                }
            }

        }

        return $this->render('update', [
            'model' => $model,
        ]);
    }
}