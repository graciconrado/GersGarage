<?php

/* @var $this yii\web\View */

use app\models\Appointments;
use app\models\AppStatus;
use yii\grid\ActionColumn;
use yii\helpers\Html;

?>

<div class="site-index container">
    <div class="row">
        <?= \yii\grid\GridView::widget([
            'dataProvider' => $services,
            'options' => [
                'class' => 'table table-stripe table-hover'
            ],
            'columns'=> [
                'id',
                'name',
                [
                    'header' => 'Price',
                    'value' => function($row){
                        return Yii::$app->formatter->asCurrency($row->price) ;
                    }
                ],
                [
                    'class' => ActionColumn::class,
                    'header' => 'Options',
                    'buttons' => [
                        'update' => function($url, $row){
                                return '<form action="/admin/service/update" class="float-left" method="post">
                                        <input type="hidden" name="_csrf" value="'.Yii::$app->request->csrfToken.'">
                                        <input type="hidden" name="serviceId" value="'.$row->id.'">
                                        <input type="submit" class="btn btn-primary" value="Update">
                                    </form>';
                        },
                        'delete' => function($url, $row){
                            if(!$row->hasRelations()){
                                return '<form action="/admin/service/delete" class="float-left" method="post">
                                        <input type="hidden" name="_csrf" value="'.Yii::$app->request->csrfToken.'">
                                        <input type="hidden" name="serviceId" value="'.$row->id.'">
                                        <input type="submit"
                                               class="btn btn-danger"
                                               value="Delete"
                                               data-confirm="Are you sure that you want to delete this service?">
                                    </form>';
                            }
                        },
                    ]
                ]
            ]
        ]);?>
    </div>
    <a href="/admin/service/insert" class="btn btn-success">New service</a>

</div>


