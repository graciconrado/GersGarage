<?php

/* @var $this yii\web\View */

use app\models\Appointments;
use app\models\AppStatus;
use yii\grid\ActionColumn;
use yii\helpers\Html;

?>

<div class="site-index container">
    <div class="row">
        <?= \yii\grid\GridView::widget([
            'dataProvider' => $appointments,
            'options' => [
                'class' => 'table table-stripe table-hover'
            ],
            'columns'=> [
                [
                    'header' => 'Id',
                    'attribute' => 'id'
                ],
                [
                    'header' => 'Status',
                    'value' => function($row){
                        return $row->appStatus->status;
                    }
                ],
                [
                    'header' => 'Customer',
                    'format' => 'raw',
                    'value' => function($row){
                        return $row->customer->firstName.' '.$row->customer->surname.'<br>'.$row->customer->phone;
                    }
                ],
                [
                    'header' => 'Service',
                    'value' => function($row){
                        return $row->service->name;
                    }
                ],
                'time',
                [
                    'header' => 'Vehicle',
                    'value' => function($row){
                        return $row->car->license;
                    }
                ],
                [
                    'header' => 'Mechanic',
                    'value' => function($row){
                        if($row->mechanic){
                            return $row->mechanic->firstName;
                        }

                        return '-';

                    }
                ],
                [
                    'class' => ActionColumn::class,
                    'header' => 'Options',
                    'buttons' => [
                        'update' => function($url, $row){
                            if($row->status != AppStatus::$STATUS_CANCELED){
                                return '<form action="/admin/appointment/update" class="float-left" method="post">
                                        <input type="hidden" name="_csrf" value="'.Yii::$app->request->csrfToken.'">
                                        <input type="hidden" name="appId" value="'.$row->id.'">
                                        <input type="submit" class="btn btn-primary" value="Update"> 
                                    </form>';
                            }

                        },
                        'delete' => function($url, $row){
                            if($row->status != AppStatus::$STATUS_CANCELED){
                                return '<form action="/admin/appointment/cancel" class="float-left" method="post">
                                        <input type="hidden" name="_csrf" value="'.Yii::$app->request->csrfToken.'">
                                        <input type="hidden" name="appId" value="'.$row->id.'">
                                        <input type="submit" 
                                               class="btn btn-danger" 
                                               value="Cancel" 
                                               data-confirm="Are you sure that you want to cancel this appointment?"> 
                                    </form>';
                            }
                        },
                    ]
                ]
            ]
        ]);?>
    </div>
    <a href="/admin/appointment/insert" class="btn btn-success">New appointment</a>

</div>


