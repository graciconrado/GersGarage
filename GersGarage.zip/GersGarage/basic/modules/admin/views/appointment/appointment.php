<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap4\ActiveForm */

use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;

?>

<div class="site-appointment">
    <div class="row">


            <div class="col-md-6 col-sm-12">
                <?php $form = ActiveForm::begin(['id' => 'appointment-form']); ?>

                <?= $form->field($model, 'date')->input('date',[
                    'onchange' => 'getHours(this)',
                    'data-csrf' => Yii::$app->request->csrfToken,
                    'data-url' => $hour,
                ]) ?>

                <?= $form->field($model, 'id_service')->dropDownList($services)?>

                <?= $form->field($model, 'id_car')->dropDownList($cars) ?>

                <?= $form->field($model, 'comment')->textarea()?>




                <div class="form-group">
                    <?= Html::submitButton('Submit', ['class' => 'btn btn-primary', 'name' => 'registerAppointment-button']) ?>
                </div>
            </div>
            <div class="col col-md-6 col-sm-12">
                <?= $form->field($model, 'time')->dropDownList([
                    '' => 'Select the date',
                ]) ?>

                <?= $form->field($model, 'id_mechanic')->dropDownList($mechanics) ?>

                <?= $form->field($model, 'status')->dropDownList($statusList)?>

                <?= $form->field($model, 'id')->hiddenInput()->label(false)?>
                <?php ActiveForm::end(); ?>
            </div>





    </div>


</div>

