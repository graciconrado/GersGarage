<?php

/* @var $this yii\web\View */

use app\models\Appointments;
use app\models\AppStatus;
use yii\grid\ActionColumn;
use yii\helpers\Html;

?>

<div class="site-index container">
    <div class="row">
        <?= \yii\grid\GridView::widget([
            'dataProvider' => $products,
            'options' => [
                'class' => 'table table-stripe table-hover'
            ],
            'columns'=> [
                'id',
                'name',
                [
                    'header' => 'Price',
                    'value' => function($row){
                        return Yii::$app->formatter->asCurrency($row->price) ;
                    }
                ],
                'quantity',
                [
                    'class' => ActionColumn::class,
                    'header' => 'Options',
                    'buttons' => [
                        'update' => function($url, $row){
                                return '<form action="/admin/product/update" class="float-left" method="post">
                                        <input type="hidden" name="_csrf" value="'.Yii::$app->request->csrfToken.'">
                                        <input type="hidden" name="prodId" value="'.$row->id.'">
                                        <input type="submit" class="btn btn-primary" value="Update">
                                    </form>';
                        },
                        'delete' => function($url, $row){
                                if(!$row->hasInvoice()){
                                    return '<form action="/admin/product/delete" class="float-left" method="post">
                                        <input type="hidden" name="_csrf" value="'.Yii::$app->request->csrfToken.'">
                                        <input type="hidden" name="prodId" value="'.$row->id.'">
                                        <input type="submit"
                                               class="btn btn-danger"
                                               value="Delete"
                                               data-confirm="Are you sure that you want to delete this product?">
                                    </form>';
                                }

                        },
                    ]
                ]
            ]
        ]);?>
    </div>
    <a href="/admin/product/insert" class="btn btn-success">New product</a>

</div>


