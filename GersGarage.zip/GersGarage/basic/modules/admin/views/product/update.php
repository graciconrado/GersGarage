<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap4\ActiveForm */

use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;

?>
<div class="site-profile">
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <?php if($product->hasErrors()):?>
                <div class="alert alert-danger">
                    Please fix the following errors:
                    <ul>
                        <?php foreach($product->getErrorSummary(true) as $error):?>
                            <li><?=$error?></li>
                        <?php endforeach;?>
                    </ul>
                </div>
            <?php endif;?>

            <?php $form = ActiveForm::begin(['id' => 'update-form']); ?>

            <?= $form->field($product, 'id')->hiddenInput()->label(false)?>

            <?= $form->field($product, 'name')->textInput(['autofocus' => true]) ?>

            <?= $form->field($product, 'quantity')->input('number', ['min' => 0]) ?>

            <?= $form->field($product, 'price', [
                'template' => '{label}
                <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">€</span>
                </div>
                {input}{error}{hint}
                </div>'
            ])->input('number', [
                'min' => 0,
                'step' => 0.01,
                'style' => 'border-bottom-right-radius: 4px; border-top-right-radius: 4px;'
            ]) ?>

            <div class="form-group">
                <?= Html::submitButton('Submit', ['class' => 'btn btn-primary', 'name' => 'update-button']) ?>
            </div>

            <?php ActiveForm::end(); ?>

        </div>
    </div>

</div>