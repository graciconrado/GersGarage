<?php

/* @var $this yii\web\View */

use app\models\Appointments;
use app\models\AppStatus;
use yii\grid\ActionColumn;
use yii\helpers\Html;

?>

<div class="site-index container">
    <div class="row">
        <?= \yii\grid\GridView::widget([
            'dataProvider' => $invoices,
            'options' => [
                'class' => 'table table-stripe table-hover'
            ],
            'columns'=> [
                'id',
                'date',
                [
                    'header' => 'Created by',
                    'value' => function($row){
                        return $row->createdBy->firstName.' '.$row->createdBy->surname;
                    }
                ],
                [
                    'header' => 'Appointment Related',
                    'format' => 'raw',
                    'value' => function($row){

                        if($row->id_appointment){
                            return $row->appointment->date.' - '.$row->appointment->time.'<br>'.$row->appointment->service->name;
                        }
                        return 'Not related to appointments';
                    }
                ],
                [
                    'header' => 'Total',
                    'value' => function($row){
                        return Yii::$app->formatter->asCurrency($row->total) ;
                    }
                ],
                [
                    'class' => ActionColumn::class,
                    'header' => 'Options',
                    'template' => '{print}{update}{delete}',
                    'buttons' => [
                        'print' => function($url, $row){
                            return '<form action="/admin/invoice/print" class="float-left" method="post">
                                        <input type="hidden" name="_csrf" value="'.Yii::$app->request->csrfToken.'">
                                        <input type="hidden" name="invId" value="'.$row->id.'">
                                        <input type="submit" class="btn btn-info" value="Print">
                                    </form>';
                        },
                        'update' => function($url, $row){
                            return '<form action="/admin/invoice/update" class="float-left" method="post">
                                        <input type="hidden" name="_csrf" value="'.Yii::$app->request->csrfToken.'">
                                        <input type="hidden" name="invId" value="'.$row->id.'">
                                        <input type="submit" class="btn btn-primary" value="Update">
                                    </form>';
                        },
                    ]
                ]
            ]
        ]);?>
    </div>
    <a href="/admin/invoice/insert" class="btn btn-success">New invoice</a>

</div>


