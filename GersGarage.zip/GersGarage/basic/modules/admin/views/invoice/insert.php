<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap4\ActiveForm */

use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;

?>

<div class="site-appointment">
    <?php $form = ActiveForm::begin(['id' => 'invoice-form']); ?>
    <div class="row">
        <div class="col-md-6 col-sm-12">
            <?= $form->field($model, 'id_appointment')->dropDownList($appList, [
                'onChange' => 'getAppDetails(this)',
                'data-url' => $appUrl,
                'data-csrf' => Yii::$app->request->csrfToken,
            ])?>

            <?= $form->field($model, 'total', [
                'template' => '{label}
                <div class="input-group mb-3">
                <div class="input-group-prepend">
                    <span class="input-group-text">€</span>
                </div>
                {input}{error}{hint}
                </div>'
            ])->input('number', [
                'min' => 0,
                'step' => 0.01,
                'style' => 'border-bottom-right-radius: 4px; border-top-right-radius: 4px;'
            ]) ?>

            <?= $form->field($model, 'id_employee')->hiddenInput(['value' => Yii::$app->user->id])->label(false)?>


        </div>
        <div class="col col-md-6 col-sm-12">
            <?= $form->field($model, 'customerName')->textInput() ?>
            <?= $form->field($model, 'date')->input('date') ?>
        </div>
        <div class="col-md-6 col-sm-12">
            <div class="form-group">
                <table class="table table-striped table-hover" id="product_table">
                    <tr><th colspan="4">Included products</th></tr>
                    <tr>
                        <th><button type="button" class="btn btn-info btn-sm" id="addRow">+</button> </th>
                        <th>Product</th>
                        <th>Quantity</th>
                        <th>Total</th>
                    </tr>
                    <?php
                        $i = 1;
                        foreach($model->productItems as $prodItem):?>

                        <tr id="<?=$i?>>" class="prod_line">
                            <td>
                                <?= $form->field($prodItem, 'id')->hiddenInput([
                                        'name' => 'InvoiceProduct['.$i.'][id]'
                                ])
                                    ->label(false)
                                    ->hint(false)
                                    ->error(false)?>
                            </td>
                            <td>
                                <select onchange="changeProd(this)"
                                        class="form-control product_select"
                                        name="InvoiceProduct[<?=$i?>][id_product]"
                                        id="prod_<?=$i?>"
                                        data-line="<?=$i?>">
                                    <option value="">-</option>
                                    <?php foreach ($products as $product):?>
                                        <option value="<?=$product->id?>"
                                                data-price="<?=$product->price?>"
                                                <?= $product->id == $prodItem->id_product ? 'selected' : ''?>
                                        ><?=$product->name.' - '.$product->price?></option>
                                    <?php endforeach;?>
                                </select>
                            </td>
                            <td>
                                <?= $form->field($invoiceProd, 'quantItem')->input('number',[
                                    'class' => 'form-control product_qtt',
                                    'data-line' => $i,
                                    'id' => 'prod_'.$i,
                                    'min' => 0,
                                    'value' => $prodItem->quantItem ?? 0,
                                    'name' => 'InvoiceProduct['.$i.'][quantItem]',
                                    'onchange' => "changeQtt(this)"
                                ])->label(false)?>
                            </td>
                            <td id="prodTotal_<?=$i?>"
                                class="total_cell"
                                data-total="<?= ($prodItem->quantItem ?? 0) * $prodItem->product->price?>"
                            ><?= ($prodItem->quantItem ?? 0) * $prodItem->product->price?></td>
                        </tr>
                        <?php $i++?>
                    <?php endforeach;?>
                    <tr id="0" class="prod_line">
                        <td></td>
                        <td>
                            <select onchange="changeProd(this)"
                                    class="form-control product_select"
                                    name="InvoiceProduct[0][id_product]"
                                    id="prod_0"
                                    data-line="0">
                                <option value="">-</option>
                                <?php foreach ($products as $product):?>
                                    <option value="<?=$product->id?>" data-price="<?=$product->price?>"><?=$product->name.' - '.$product->price?></option>
                                <?php endforeach;?>
                            </select>
                        </td>
                        <td>
                            <?= $form->field($invoiceProd, 'quantItem')->input('number',[
                                'class' => 'form-control product_qtt',
                                'data-line' => 0,
                                'id' => 'prod_0',
                                'min' => 0,
                                'name' => 'InvoiceProduct[0][quantItem]',
                                'onchange' => "changeQtt(this)"
                            ])->label(false)?>
                        </td>
                        <td id="prodTotal_0"
                            class="total_cell"
                            data-total="0"
                        ></td>
                    </tr>
                </table>
            </div>

        </div>
        <div class="col-md-6 col-sm-12">
            <div class="form-group">
                <table class="table table-striped table-hover" id="service_table">
                    <tr><th colspan="2">Included service</th></tr>
                    <tr>
                        <th>Service</th>
                        <th>Total</th>
                    </tr>
                    <tr>
                        <?php if($model->appointment):?>
                            <td id="servName">
                                <?= $model->appointment->service->name?>
                            </td>
                            <td id="servPrice" data-price="<?= $model->appointment->service->price?>">
                                <?= $model->appointment->service->price?>
                            </td>
                        <?php else:?>
                            <td id="servName">
                                - No service related -
                            </td>
                            <td id="servPrice">
                                -
                            </td>
                        <?php endif;?>
                    </tr>
                </table>
                <?= $form->field($model, 'id')->hiddenInput()->label(false)?>
                <?= Html::submitButton('Submit', ['class' => 'btn btn-primary', 'name' => 'registerAppointment-button']) ?>
            </div>

        </div>
    </div>
    <?php ActiveForm::end(); ?>
</div>

