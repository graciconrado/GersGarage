<?php

/* @var $this yii\web\View */

use app\models\Appointments;
use app\models\AppStatus;
use yii\grid\ActionColumn;
use yii\helpers\Html;

?>

<div class="site-index container">
    <div class="row">
        <div class="col-12 box">
            Ger's Garage
        </div>
        <div class="col-12 title">
            Invoice
        </div>
        <div class="col-12 customer">
            <?=$inv->customerName?>
            <?php if($inv->appointment):?>
            <hr>
            Appointment number <?=$inv->id?> /
            at <?= $inv->appointment->date ?> - <?=$inv->appointment->time?><br>

            <?= $inv->appointment->mechanic ?
                    'Mechanic: '.$inv->appointment->mechanic->firstName.' '.$inv->appointment->mechanic->surname :
                    ''
            ?>
            <hr>
            <?php endif;?>
        </div>
        <div class="col-12 service">
            <span class="title">Services</span>
            <table class="table item-table">
                <?php if($inv->appointment && $inv->appointment->service):?>
                    <tr>
                        <td><?= $inv->appointment->service->name?></td>
                        <td><?= Yii::$app->formatter->asCurrency($inv->appointment->service->price)?></td>
                    </tr>
                <?php else:?>
                    <tr>
                        <td colspan="2"> - No services related -</td>
                    </tr>
                <?php endif;?>
            </table>
        </div>
        <div class="col-12 products">
            <span class="title">Products</span>
            <table class="table item-table">
                <tr>
                    <th>Product</th>
                    <th>Quantity</th>
                    <th>Value</th>
                    <th>Total</th>
                </tr>
                <?php if($inv->productItems):?>
                    <?php foreach($inv->productItems as $prodItem):?>
                        <tr>
                            <td><?= $prodItem->product->name?></td>
                            <td><?= $prodItem->quantItem?></td>
                            <td><?= Yii::$app->formatter->asCurrency($prodItem->product->price)?></td>
                            <td><?= Yii::$app->formatter->asCurrency($prodItem->product->price * $prodItem->quantItem)?></td>

                        </tr>
                    <?php endforeach;?>
                <?php else:?>
                    <tr>
                        <td colspan="4"> - No products bought -</td>
                    </tr>
                <?php endif;?>
            </table>
        </div>
        <div class="total">
            <?= Yii::$app->formatter->asCurrency($inv->total)?>
        </div>
    </div>


</div>


