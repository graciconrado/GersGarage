<?php

/* @var $this yii\web\View */

use app\models\Appointments;
use app\models\AppStatus;
use app\models\User;
use yii\grid\ActionColumn;
use yii\grid\GridView;
use yii\helpers\Html;

?>

<div class="site-index container">
    <div class="row">
        <?= GridView::widget([
            'dataProvider' => $employees,
            'options' => [
                'class' => 'table table-stripe table-hover'
            ],
            'columns' => [
                'firstName',
                'surname',
                'birthday',
                'email',
                'phone',
                [
                    'header' => 'Type',
                    'value' => function($row){
                        return User::$TYPE_LIST[$row->userType];
                    }
                ],
                [
                    'header' => 'Status',
                    'value' => function($row){

                        return $row->status ? 'Active': 'Inactive';
                    }
                ],
                [
                    'class' => ActionColumn::class,
                    'header' => 'Options',
                    'buttons' => [
                        'update' => function($url, $row){
                            if($row->userType != User::$ADMIN_TYPE){
                                return '<form action="/admin/employee/update" class="float-left" method="post">
                                        <input type="hidden" name="_csrf" value="'.Yii::$app->request->csrfToken.'">
                                        <input type="hidden" name="id" value="'.$row->userId.'">
                                        <input type="submit" class="btn btn-primary" value="Update">
                                    </form>';
                            }

                        },
                        'delete' => function($url, $row){
                            if(
                                $row->userType != User::$ADMIN_TYPE &&
                                !$row->hasAppointment()
                            ){
                                return '<form action="/admin/employee/delete" class="float-left" method="post">
                                        <input type="hidden" name="_csrf" value="'.Yii::$app->request->csrfToken.'">
                                        <input type="hidden" name="id" value="'.$row->userId.'">
                                        <input type="submit"
                                               class="btn btn-danger"
                                               value="Delete"
                                               data-confirm="Are you sure that you want to delete this employee?">
                                    </form>';
                            }
                        },
                    ]
                ]
            ]
        ]);?>
    </div>
    <a href="/admin/employee/new-employee" class="btn btn-success">New employee</a>

</div>


