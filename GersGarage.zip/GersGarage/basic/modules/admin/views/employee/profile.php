<?php

/* @var $this yii\web\View */
/* @var $form yii\bootstrap4\ActiveForm */
/* @var $model app\models\User */

use yii\helpers\Html;
use yii\bootstrap4\ActiveForm;

?>
<div class="site-profile">

    <div class="row">
        <div class="col-md-6 col-sm-12">
            <?php if($employee->hasErrors()):?>
                <div class="alert alert-danger">
                    Please fix the following errors:
                    <ul>
                        <?php foreach($employee->getErrorSummary(true) as $error):?>
                            <li><?=$error?></li>
                        <?php endforeach;?>
                    </ul>
                </div>
            <?php endif;?>

            <?php $form = ActiveForm::begin(['id' => 'update-form']); ?>

            <?= $form->field($employee, 'firstName')->textInput(['autofocus' => true]) ?>

            <?= $form->field($employee, 'surname') ?>

            <?= $form->field($employee, 'phone')->textInput(['maxlength' => 20]) ?>

            <?=$form->field($employee, 'userId')->hiddenInput()->label(false)?>

            <div class="form-group">
                <?= Html::submitButton('Submit', ['class' => 'btn btn-primary', 'name' => 'update-button']) ?>
            </div>



        </div>
        <div class="col-sm-12 col-md-6">
            <?= $form->field($employee, 'email')?>

            <?= $form->field($employee, 'birthday')->input('date') ?>

            <?= $form->field($employee, 'status')->dropDownList([
                    '1' => 'Active',
                    '0' => 'Inactive',
            ])?>

            <?php ActiveForm::end(); ?>
        </div>
    </div>

</div>
