<?php


namespace app\modules\admin\controllers;


use app\models\Product;
use yii\data\ActiveDataProvider;
use Yii;

class ProductController extends BaseController
{
    public function actionIndex()
    {
        $this->view->title = 'Products';

        $dataProvider = new ActiveDataProvider([
            'query' => Product::find(),
            'pagination' => [
                'pageSize' => 20,
            ],
            'sort' => false
        ]);

        return $this->render('index', [
            'products' => $dataProvider
        ]);
    }

    public function actionInsert()
    {
        $this->view->title = 'New product';

        $product = new Product();

        if($product->load(\Yii::$app->request->post()) && $product->validate()){
            if($product->save()){
                return $this->redirect('/admin/product');
            }
        }

        return $this->render('insert',[
            'product' => $product
        ]);

    }

    public function actionUpdate()
    {
        $this->view->title = 'Update product';

        $product = new Product();

        $productId = Yii::$app->request->post('prodId');


        $product = Product::findOne($productId);
        
        $newData = Yii::$app->request->post('Product') ?? [];

        if(isset($newData['id'])){
            $product = Product::findOne($newData['id']);

            if($product->load(Yii::$app->request->post()) && $product->validate()){
                if($product->save()){
                    return $this->redirect('/admin/product');
                }
            }
        }


        return $this->render('update',[
            'product' => $product
        ]);

    }

    public function actionDelete()
    {
        $productId = Yii::$app->request->post('prodId');

        $product = Product::findOne($productId);

        if($product && !$product->hasInvoice()){
            $product->delete();
            return  $this->redirect('/admin/product');
        }
    }

}