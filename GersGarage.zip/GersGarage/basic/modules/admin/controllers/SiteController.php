<?php


namespace app\modules\admin\controllers;


use app\models\Appointments;
use app\models\AppStatus;
use app\models\Cars;
use app\models\Employee;
use app\models\Hour;
use app\models\User;
use PHPUnit\Util\Log\JSON;
use Yii;
use yii\data\ActiveDataProvider;
use yii\filters\AccessControl;
use yii\web\Controller;
use yii\web\Response;

class SiteController extends BaseController
{

    public function actionIndex()
    {
        $this->layout = 'main';
        $this->view->title = 'Today\'s Agenda';

        $dataProvider = new ActiveDataProvider([
            'query' => Appointments::find()->where([
                'date' => date('Y-m-d'),

            ])->orderBy('time'),
            'pagination' => [
                'pageSize' => 20,
            ],
            'sort' => false
        ]);

        return $this->render('index', [
            'appointments' => $dataProvider
        ]);
    }
}