<?php


namespace app\modules\admin\controllers;


use app\models\User;
use yii\filters\AccessControl;
use yii\web\Controller;
use Yii;

class BaseController extends Controller
{
    public function behaviors()
    {
        return [
            'access' => [
                'class'=> AccessControl::class,
                'rules' => [
                    [
                        'allow' => true,
                        'matchCallback' => function ($rule, $action) {
                            if($action->id == 'get-hours'){
                                return !Yii::$app->user->isGuest;
                            }
                            return !Yii::$app->user->isGuest  && Yii::$app->user->identity->userType !== User::$CUSTOMER_TYPE;
                        }
                    ]
                ],
            ]
        ];
    }

    public function beforeAction($action)
    {
        $this->layout = 'main';

        return parent::beforeAction($action);
    }
}