<?php


namespace app\modules\admin\controllers;

use app\models\Employee;
use app\models\User;
use Prophecy\Argument;
use yii\data\ActiveDataProvider;
use yii\filters\AccessControl;
use yii\web\Controller;
use Yii;

class EmployeeController extends BaseController
{

    public function actionIndex()
    {
        $this->view->title = 'Employees';
        
        $dataProvider = new ActiveDataProvider([
            'query' => Employee::find()->where('userType != '.User::$CUSTOMER_TYPE),
            'pagination' => [
                'pageSize' => 20,
            ],
            'sort' => false
        ]);

        return $this->render('index', [
            'employees' => $dataProvider
        ]);
    }

    public function actionNewEmployee()
    {
        $this->layout = 'main';
        $this->view->title = 'New Employee';

        $model = new User();

        if($model->load(Yii::$app->request->post()) && $model->validate()){
            $model->password = crypt($model->password, User::$PASSWORD_SALT);
            if($model->save()){
                return  $this->redirect('/admin/employee');
            }
        }

        return $this->render('insert', [
            'user' => $model,
        ]);
    }

    public function actionDelete()
    {
        $employeeId = Yii::$app->request->post('id');

        $employee = Employee::findOne($employeeId);

        if($employee && !$employee->hasAppointment()){
            $employee->delete();
            return  $this->redirect('/admin/employee');
        }
    }

    public function actionUpdate()
    {
        $this->layout = 'main';
        $this->view->title = 'Employee Profile';

        $employeeId = Yii::$app->request->post('id');

        $employee = Employee::findOne($employeeId);

        $newData = Yii::$app->request->post('Employee') ?? [];

        if(isset($newData['userId'])){
            $employee = Employee::findOne($newData['userId']);

            if($employee->load(Yii::$app->request->post()) && $employee->validate()){
                $employee->save();
            }

            return $this->redirect('/admin/employee');
        }

        return $this->render('profile',[
            'employee' => $employee,
        ]);
    }

}