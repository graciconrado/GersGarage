<?php


namespace app\modules\admin\controllers;


use app\models\Service;
use yii\data\ActiveDataProvider;
use Yii;

class ServiceController extends BaseController
{
    public function actionIndex()
    {
        $this->view->title = 'Services';

        $dataProvider = new ActiveDataProvider([
            'query' => Service::find(),
            'pagination' => [
                'pageSize' => 20,
            ],
            'sort' => false
        ]);

        return $this->render('index', [
            'services' => $dataProvider
        ]);
    }

    public function actionInsert()
    {
        $this->view->title = 'New service';

        $service = new Service();

        if($service->load(\Yii::$app->request->post()) && $service->validate()){
            if($service->save()){
                return $this->redirect('/admin/service');
            }
        }

        return $this->render('insert',[
            'service' => $service
        ]);

    }

    public function actionUpdate()
    {
        $this->view->title = 'Update service';

        $service = new Service();

        $serviceId = Yii::$app->request->post('serviceId');


        $service = Service::findOne($serviceId);
        
        $newData = Yii::$app->request->post('Service') ?? [];

        if(isset($newData['id'])){
            $service = Service::findOne($newData['id']);

            if($service->load(Yii::$app->request->post()) && $service->validate()){
                if($service->save()){
                    return $this->redirect('/admin/service');
                }
            }
        }


        return $this->render('update',[
            'service' => $service
        ]);

    }

    public function actionDelete()
    {
        $serviceId = Yii::$app->request->post('serviceId');

        $service = Service::findOne($serviceId);

        if($service && !$service->hasInvoice()){
            $service->delete();
            return  $this->redirect('/admin/service');
        }
    }

}