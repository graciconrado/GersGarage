<?php


namespace app\modules\admin\controllers;


use app\models\Appointments;
use app\models\AppStatus;
use app\models\Cars;
use app\models\Employee;
use app\models\Hour;
use app\models\Service;
use app\models\User;
use yii\data\ActiveDataProvider;
use Yii;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;

class AppointmentController extends BaseController
{
    public function actionIndex($id)
    {
        $appStatus = AppStatus::findOne($id);

        if($appStatus){
            $this->view->title = $appStatus->status;
        }

        $dataProvider = new ActiveDataProvider([
            'query' => Appointments::find()->where([
                'status' => $appStatus->id

            ])->orderBy('date'),
            'pagination' => [
                'pageSize' => 20,
            ],
            'sort' => false
        ]);

        return $this->render('index', [
            'appointments' => $dataProvider
        ]);
    }

    public function actionUpdate()
    {
        $this->view->title = 'Appointment';

        $appointment = new Appointments();

        $appId = Yii::$app->request->post('appId');

        $carsList = ['' => 'Select'] + Cars::getCarList();

        $mechanicList = ['' => 'Select'] + Employee::getMechanicList();

        $statusList = ['' => 'Select'] + AppStatus::getList();

        $serviceList = ['' => 'Select'] + Service::getList();

        if($appId){
            Yii::$app->user->setReturnUrl(str_replace(Yii::$app->request->getHostInfo(), '',Yii::$app->request->referrer) ?? '/admin');
            $appointment = Appointments::findOne(['id' => $appId]);

            $appointment->time = date('H:i', strtotime($appointment->time));

            return $this->render('appointment', [
                'model' => $appointment,
                'cars' => $carsList,
                'mechanics' => $mechanicList,
                'statusList' => $statusList,
                'services' => $serviceList,
                'hour' => Url::to(['/admin/appointment/get-hours'], true),
            ]);
        }



        if($appointment->load(Yii::$app->request->post())){
            $appointment = Appointments::findOne(['id' => $appointment->id]);
            if($appointment->load(Yii::$app->request->post()) && $appointment->validate()){
                if($appointment->save()) {
                    return $this->redirect(Yii::$app->user->getReturnUrl());
                }
            }

        }

        return $this->render('appointment', [
            'model' => $appointment,
            'cars' => $carsList,
            'mechanics' => $mechanicList,
            'statusList' => $statusList,
            'services' => $serviceList,
            'hour' => Url::to(['/admin/appointment/get-hours'], true),
        ]);



    }

    public function actionCancel()
    {
        $appId = Yii::$app->request->post('appId');

        if($appId){
            $appointment = Appointments::findOne(['id' => $appId]);
            $appointment->status = AppStatus::$STATUS_CANCELED;
            $appointment->save();

        }

        $returnTo = str_replace(Yii::$app->request->getHostInfo(), '',Yii::$app->request->referrer) ?? '/admin';

        return $this->redirect($returnTo);


    }

    public function actionInsert()
    {
        $this->view->title = 'New appointment';

        $appointment = new Appointments();

        if($appointment->load(Yii::$app->request->post())){
            $appointment->id_customer = $appointment->car->user->id;

            if($appointment->save()){
                return $this->redirect(Yii::$app->user->getReturnUrl());
            }
        }else{
            Yii::$app->user->setReturnUrl(str_replace(Yii::$app->request->getHostInfo(), '',Yii::$app->request->referrer) ?? '/admin');
        }

        $carsList = ['' => 'Select'] + Cars::getCarList();

        $mechanicList = ['' => 'Select'] + Employee::getMechanicList();

        $statusList = ['' => 'Select'] + AppStatus::getList();

        $serviceList = ['' => 'Select'] + Service::getList();

        return $this->render('insert', [
            'model' => $appointment,
            'cars' => $carsList,
            'mechanics' => $mechanicList,
            'statusList' => $statusList,
            'services' => $serviceList,
            'hour' => Url::to(['/admin/appointment/get-hours'], true),
        ]);
    }

    public function actionGetData()
    {
        Yii::$app->response->format = 'json';

        $appId =Yii::$app->request->post('appId');

        $appointment = Appointments::findOne($appId);

        if($appointment){
            return [
                'success' => true,
                'customer' => $appointment->customer->firstName.' '.$appointment->customer->surname,
                'serviceName' => $appointment->service->name,
                'servicePrice' => $appointment->service->price,
            ];
        }

        return ['success' => false];
    }

    public function actionGetHours()
    {
        Yii::$app->response->format = 'json';

        $date =Yii::$app->request->post('date');
        $list = '';

        foreach(Hour::getListHours(true, $date) as $hour){
            $list .= '<option value="'.$hour.'">'.$hour.'</option>';
        }

        return $list;

    }
}