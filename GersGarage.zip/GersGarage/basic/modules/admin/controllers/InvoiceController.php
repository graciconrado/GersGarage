<?php


namespace app\modules\admin\controllers;

use app\models\Appointments;
use app\models\AppStatus;
use app\models\InvoiceProduct;
use app\models\Product;
use yii\helpers\Url;
use Yii;
use app\models\Invoice;
use yii\data\ActiveDataProvider;


class InvoiceController extends BaseController
{
    public function actionIndex()
    {

        $this->view->title = 'Invoices';

        $dataProvider = new ActiveDataProvider([
            'query' => Invoice::find(),
            'pagination' => [
                'pageSize' => 20,
            ],
            'sort' => false
        ]);

        return $this->render('index', [
            'invoices' => $dataProvider
        ]);
    }

    public function actionInsert()
    {
        $this->view->title = 'New Invoice';

        $invoice = new Invoice();
        $products = Product::find()->all();
        $invoiceProd = new InvoiceProduct();

        $appList = ['' => 'No appointment related'] + Appointments::getList(AppStatus::$STATUS_FIXED, true);

        if($invoice->load(Yii::$app->request->post()) && $invoice->validate()){
            if($invoice->save()){
                $invoiceProducts = Yii::$app->request->post('InvoiceProduct');
                if(isset($invoiceProducts['line_0'])){
                    foreach ($invoiceProducts  as $invProd){
                        $invoiceProd = new InvoiceProduct();

                        $invoiceProd->id_invoice = $invoice->id;
                        $invoiceProd->id_product = $invProd['id_product'];
                        $invoiceProd->quantItem = $invProd['quantItem'];

                        if($invoiceProd->validate()){
                            $invoiceProd->save();
                        }
                    }                }


                return $this->redirect('/admin/invoice');
            }
        }

        return $this->render('insert',[
            'model' => $invoice,
            'appList' => $appList,
            'products' => $products,
            'invoiceProd' => $invoiceProd,
            'appUrl' => Url::to(['/admin/appointment/get-data'], true),
        ]);
    }

    public function actionUpdate()
    {
        if(Yii::$app->request->post('Invoice')){
            $invId = Yii::$app->request->post('Invoice')['id'];
            $inv = Invoice::findOne($invId);
            if($inv->load(Yii::$app->request->post()) && $inv->validate()){
                $inv->save();

                if(Yii::$app->request->post('InvoiceProduct')){
                    foreach (Yii::$app->request->post('InvoiceProduct') as $prodItem){
                        if(isset($prodItem['id'])){
                            $item = InvoiceProduct::findOne($prodItem['id']);
                            if($item){
                                $temp['InvoiceProduct'] = $prodItem;
                                if($item->load($temp) && $item->validate()){
                                    $item->save();
                                }
                            }
                        }else{
                            $newProd = new InvoiceProduct();
                            $newProd->id_invoice = $inv->id;
                            $newProd->id_product = $prodItem['id_product'];
                            $newProd->quantItem = $prodItem['quantItem'];
                            if($newProd->validate()) {
                                $newProd->save();
                            }
                        }

                    }
                }
                return $this->redirect('/admin/invoice');
            }

        }


        $invId = Yii::$app->request->post('invId');

        $appList = ['' => 'No appointment related'] + Appointments::getList(AppStatus::$STATUS_FIXED, true);

        $inv = Invoice::findOne($invId);
        $products = Product::find()->all();
        $invoiceProd = new InvoiceProduct();

        if($inv->appointment){
            $appList[$inv->appointment->id] = $inv->appointment->date.'-'.$inv->appointment->time.' / '.
                $inv->appointment->customer->firstName.' '.$inv->appointment->customer->surname;

        }

        if(!$inv){
            $this->redirect('/admin/invoice');
        }





        return $this->render('insert',[
            'model' => $inv,
            'appList' => $appList,
            'products' => $products,
            'invoiceProd' => $invoiceProd,
            'appUrl' => Url::to(['/admin/appointment/get-data'], true),
        ]);


    }

    public function actionPrint()
    {
        $this->layout = 'empty';

        $invId = Yii::$app->request->post('invId');

        $inv = Invoice::findOne($invId);


        return $this->render('print',[
            'inv' => $inv
        ]);
    }
}